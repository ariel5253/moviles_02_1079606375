package com.corhuila.fuenteshidricas;

public class Persona {
    private Integer id;
    private String nombre;
}
